let mx = 0;
let my = 0;
let px = 0;
let py = 0;
let fr = 0;


function setup() {

  createCanvas(400, 400);
  background(32);

let fr = 60;
frameRate(fr);

}

function draw() {

let fr = abs(60);
frameRate(fr);

print(fr);

	let mx = mouseX;
	let my = mouseY;
	let px = pmouseX;
	let py = pmouseY;

	var weight = dist(mx, my, px, py);

  colorMode(RGB, 255, 255, 255, 1);

  
  strokeWeight (weight);
  stroke(130, 20, 240, 0.5);
  point(mx, my, px, py);

  
  strokeWeight(4)
  stroke(90, 90, 240);
  fill(205, 150, 255);
  
	beginShape();

		vertex(1, 1);

		vertex(400, 1);
		
		vertex(400, 400);

		vertex(1, 400);

		beginContour();

			vertex(30, 30);
			
			vertex(30, 370);
			
			vertex(370, 370);
			
			vertex(370, 30);

		endContour();
	
	endShape(CLOSE);
  
    fill(50, 190, 120, 0.1)

}




