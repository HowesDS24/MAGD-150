var x1 = 100;

var y1 = 420;

var w = 80;

var h = 40;


  var x2 = 230;

  var y2 = 440;

  var radius = 20;


function setup() {

	createCanvas(600, 500);

	background (100);

    fill (80, 55, 5);

	rect(x1, y1, w, h);

  	ellipseMode (RADIUS);

	ellipse(x2, y2, radius, radius);
   
}


function draw() {

  colorMode(RGB, 255, 255, 255, 1);
  
  //turn on tv button
  
  var d = dist(mouseX, mouseY, x2, y2);  

if (keyIsPressed) {
		
  if (key == 'x') {
				
    if (d < radius) {
					
		fill(200)	
        rect(30, 30, 540, 320)	  
		fill(60, 40, 20);

		  } else {
		
			fill (80, 55, 5);
				
		  }
	
        ellipse(x2, y2, radius, radius);
       
  }
}
  
  
  fill(80, 55, 5);
  
beginShape();

		vertex(1, 1);

		vertex(600, 1);
		
		vertex(600, 380);

		vertex(1, 380);

  beginContour();

			vertex(30, 30);
			
			vertex(30, 350);
			
			vertex(570, 350);
			
			vertex(570, 30);

  endContour();
	
endShape(CLOSE);


beginShape();

		vertex(1, 380);

		vertex(600, 380);
		
		vertex(600, 500);

		vertex(1, 500);

  beginContour();
 
            vertex(30, 470);
			
		    vertex(570, 470);
			
		    vertex(570, 410);
			
			vertex(30, 410);

  endContour();
  
endShape(CLOSE);

  stroke(60, 40, 20)
  strokeWeight(5)
  
line(20, 480, 20, 20)

line(20, 20, 580, 20)

line(580, 20, 580, 480)

line(20, 480, 580, 480)  
  
   
strokeWeight(9)
stroke(60)

  //left speakers
  
  point(50, 425)  
  point(65, 425)  
  point(80, 425)  

    point(50, 440)  
    point(65, 440)
    point(80, 440)  
  
      point(50, 455)  
      point(65, 455)
      point(80, 455)  
  
  //right speakers
  
  point(520, 425)  
  point(535, 425)  
  point(550, 425)  
  
    point(520, 440)  
    point(535, 440)
    point(550, 440)  
  
      point(520, 455)  
      point(535, 455)
      point(550, 455)  
  
line(470, 432.5, 300, 432.5)
line(470, 450, 300, 450)
  
  
  
  
  
noStroke()
  
}

function mousePressed() {

	//turn off tv button
  
	if ((mouseX > x1) && (mouseX < x1+w) && (mouseY > y1) && (mouseY < y1+h)) {

      fill(100)	
      rect(30, 30, 540, 320)	
	  fill(60, 40, 20);

    }

	else {

		fill (80, 55, 5);

	}
	
	rect(x1, y1, w, h);




}

