var img1;
var quote1 = "Ferrari F1 2017"

var img2;
var quote2 = "Mercedes F1 2020"

var img3;
var quote3 = "Mclaren F1 1988"




function preload() {

	

	img1 = loadImage("vettelferrari.png");
    img2 = loadImage("hamiltonmercedes.jpg");
    img3 = loadImage("sennamclaren.jpg"); 
  
}

function setup () {

	createCanvas(700, 700);
    
    textFont("Helvetica");
  
    fill(0);

	stroke(255);
    
}

function draw () {

	background(204);
   
  
    image(img1, 0, 0, 300, 100);
	image(img1, 0, 0, mouseX * 1, 100);
    textSize(20);
	text(quote1, 350, 60, 200, 200);


    image(img2, mouseX, mouseY, 300, 200);
    textSize(20);
    text(quote2, 350, 180, 200, 200);

  
    image(img3, 0, 300, 280, 200);
    textSize(20);
    text(quote3, 350, 350, 200, 200)









}